import os
import sys
from urllib.parse import quote_plus

from PySide6.QtCore import QObject, Qt, QUrl, Slot
from PySide6.QtGui import QAction, QKeySequence, QShortcut
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import (
    QApplication, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QPushButton, QTabWidget, QToolBar, QVBoxLayout, QWidget
)

APP_NAME = "WritersJumbler MultiSearch"

SEARCH_ENGINES = {
    "Bing": "https://www.bing.com/search?q={query}",
    "Google": "https://www.google.com/search?q={query}",
    "DuckDuckGo": "https://duckduckgo.com/?q={query}",
    "Yahoo": "https://search.yahoo.com/search?p={query}",
    "Wiby": "https://wiby.me/?q={query}",
    "Wikipedia": "https://en.wikipedia.org/w/index.php?search={query}&title=Special%3ASearch",
    "Brave": "https://search.brave.com/search?q={query}",
    "Mojeek": "https://www.mojeek.com/search?q={query}",
    "Qwant": "https://www.qwant.com/?q={query}&t=web",
    "Ecosia": "https://www.ecosia.org/search?q={query}",
    "Swisscows": "https://swisscows.com/en/web?query={query}",
}


def app_directory():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


class BrowserPage(QWebEnginePage):
    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.window = window

    def createWindow(self, window_type):
        view = self.window.add_browser_tab("New Tab", switch_to=True)
        return view.page()


class BrowserView(QWebEngineView):
    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.window = window
        self.setPage(BrowserPage(window, self))


class SearchBridge(QObject):
    def __init__(self, window):
        super().__init__(window)
        self.window = window

    @Slot(str, "QVariantList")
    def search(self, query, engines):
        query = str(query).strip()
        valid = [str(name) for name in engines if str(name) in SEARCH_ENGINES]
        if not query:
            self.window.show_status("Enter a search phrase.")
            return
        if not valid:
            self.window.show_status("Select at least one search engine.")
            return
        self.window.run_multi_search(query, valid)

    @Slot()
    def closeAllResults(self):
        self.window.close_all_result_tabs()

    @Slot()
    def newTab(self):
        self.window.create_blank_tab()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.search_view = None
        self.search_bridge = None
        self.search_channel = None

        self.setWindowTitle(APP_NAME)
        self.resize(1400, 900)
        self.setMinimumSize(900, 600)

        self.build_ui()
        self.build_toolbar()
        self.build_shortcuts()
        self.create_search_tab()
        self.show_status("Ready")

    def build_ui(self):
        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setMovable(True)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_requested_tab)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        layout.addWidget(self.tabs)
        self.setCentralWidget(root)

        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("padding:4px 10px;")
        self.statusBar().addWidget(self.status_label, 1)

    def build_toolbar(self):
        bar = QToolBar("Browser")
        bar.setMovable(False)
        self.addToolBar(bar)

        self.back_action = QAction("Back", self)
        self.back_action.setShortcut(QKeySequence.Back)
        self.back_action.triggered.connect(lambda: self.call_current("back"))

        self.forward_action = QAction("Forward", self)
        self.forward_action.setShortcut(QKeySequence.Forward)
        self.forward_action.triggered.connect(lambda: self.call_current("forward"))

        self.reload_action = QAction("Reload", self)
        self.reload_action.setShortcut(QKeySequence.Refresh)
        self.reload_action.triggered.connect(lambda: self.call_current("reload"))

        self.stop_action = QAction("Stop", self)
        self.stop_action.triggered.connect(lambda: self.call_current("stop"))

        self.home_action = QAction("Search", self)
        self.home_action.triggered.connect(self.show_search_tab)

        self.new_action = QAction("New Tab", self)
        self.new_action.setShortcut(QKeySequence("Ctrl+T"))
        self.new_action.triggered.connect(self.create_blank_tab)

        self.close_action = QAction("Close Tab", self)
        self.close_action.setShortcut(QKeySequence("Ctrl+W"))
        self.close_action.triggered.connect(self.close_current_tab)

        for action in (self.back_action, self.forward_action, self.reload_action,
                       self.stop_action, self.home_action, self.new_action,
                       self.close_action):
            bar.addAction(action)
            if action in (self.stop_action, self.close_action):
                bar.addSeparator()

        self.address = QLineEdit()
        self.address.setClearButtonEnabled(True)
        self.address.setPlaceholderText("Enter a website address or search phrase")
        self.address.returnPressed.connect(self.navigate_address)
        bar.addWidget(self.address)

        go = QPushButton("Go")
        go.clicked.connect(self.navigate_address)
        bar.addWidget(go)

    def build_shortcuts(self):
        self.shortcuts = []
        for keys, method in (
            ("Ctrl+L", self.focus_address),
            ("Ctrl+K", self.show_search_tab),
            ("Ctrl+Tab", self.next_tab),
            ("Ctrl+Shift+Tab", self.previous_tab),
        ):
            shortcut = QShortcut(QKeySequence(keys), self)
            shortcut.activated.connect(method)
            self.shortcuts.append(shortcut)

    def create_search_tab(self):
        path = os.path.join(app_directory(), "search.html")
        if not os.path.isfile(path):
            QMessageBox.critical(self, APP_NAME,
                "search.html was not found. Place it beside main.py.")
            return

        self.search_view = QWebEngineView()
        self.search_bridge = SearchBridge(self)
        self.search_channel = QWebChannel(self.search_view.page())
        self.search_channel.registerObject("searchBridge", self.search_bridge)
        self.search_view.page().setWebChannel(self.search_channel)
        self.search_view.urlChanged.connect(self.update_address)
        self.search_view.loadFinished.connect(
            lambda ok: self.show_status("Search page ready" if ok else "Search page failed to load")
        )
        self.search_view.setUrl(QUrl.fromLocalFile(path))
        self.tabs.addTab(self.search_view, "Search")
        self.tabs.setCurrentWidget(self.search_view)

    def add_browser_tab(self, title="New Tab", url=None, switch_to=True):
        view = BrowserView(self)
        view.setProperty("base_title", title)
        view.urlChanged.connect(self.update_address)
        view.titleChanged.connect(self.update_title)
        view.iconChanged.connect(self.update_icon)
        view.loadStarted.connect(lambda v=view: self.load_started(v))
        view.loadProgress.connect(lambda p, v=view: self.load_progress(v, p))
        view.loadFinished.connect(lambda ok, v=view: self.load_finished(v, ok))
        index = self.tabs.addTab(view, title)
        self.tabs.setTabToolTip(index, title)
        if switch_to:
            self.tabs.setCurrentWidget(view)
        if url:
            view.setUrl(QUrl(url))
        return view

    def run_multi_search(self, query, engines):
        encoded = quote_plus(query)
        first = None
        for engine in engines:
            url = SEARCH_ENGINES[engine].format(query=encoded)
            view = self.add_browser_tab(engine, url, switch_to=False)
            if first is None:
                first = view
        if first:
            self.tabs.setCurrentWidget(first)
        self.show_status(f'Opened {len(engines)} result tabs for "{query}".')

    def create_blank_tab(self):
        view = self.add_browser_tab("New Tab", switch_to=True)
        view.setHtml("""<!doctype html><html><head><meta charset='utf-8'>
        <title>New Tab</title><style>body{margin:0;min-height:100vh;display:grid;
        place-items:center;background:#111827;color:#e5efff;font-family:Segoe UI,Arial}
        main{text-align:center}p{color:#aebfdb}</style></head><body><main>
        <h1>New Browser Tab</h1><p>Enter an address or search phrase above.</p>
        </main></body></html>""", QUrl("about:blank"))
        self.address.clear()
        self.address.setFocus()

    def current_view(self):
        view = self.tabs.currentWidget()
        return view if isinstance(view, QWebEngineView) else None

    def call_current(self, method):
        view = self.current_view()
        if view:
            getattr(view, method)()

    def navigate_address(self):
        text = self.address.text().strip()
        if not text:
            return
        view = self.tabs.currentWidget()
        if view is self.search_view or not isinstance(view, BrowserView):
            view = self.add_browser_tab("Browser", switch_to=True)
        view.setUrl(self.text_to_url(text))

    def text_to_url(self, text):
        low = text.lower()
        if low.startswith(("http://", "https://", "file://", "about:")):
            return QUrl(text)
        if " " not in text and "." in text:
            return QUrl.fromUserInput(text)
        return QUrl("https://www.bing.com/search?q=" + quote_plus(text))

    def close_requested_tab(self, index):
        if self.tabs.widget(index) is self.search_view:
            self.show_status("The Search tab stays open.")
            self.tabs.setCurrentIndex(index)
            return
        self.remove_tab(index)

    def close_current_tab(self):
        index = self.tabs.currentIndex()
        if index >= 0:
            self.close_requested_tab(index)

    def remove_tab(self, index):
        widget = self.tabs.widget(index)
        self.tabs.removeTab(index)
        if widget:
            widget.deleteLater()
        if self.tabs.count() == 1:
            self.show_search_tab()

    def close_all_result_tabs(self):
        for index in range(self.tabs.count() - 1, -1, -1):
            if self.tabs.widget(index) is not self.search_view:
                self.remove_tab(index)
        self.show_search_tab()
        self.show_status("All result tabs closed.")

    def show_search_tab(self):
        if self.search_view and self.tabs.indexOf(self.search_view) >= 0:
            self.tabs.setCurrentWidget(self.search_view)
            self.search_view.page().runJavaScript(
                "const q=document.getElementById('searchQuery');if(q){q.focus();q.select();}"
            )

    def current_tab_changed(self, index):
        view = self.tabs.widget(index)
        if not isinstance(view, QWebEngineView):
            return
        self.update_address(view.url(), view)
        search = view is self.search_view
        self.back_action.setEnabled(not search)
        self.forward_action.setEnabled(not search)
        self.address.setEnabled(not search)
        self.setWindowTitle(APP_NAME if search else f"{view.title() or 'Browser'} - {APP_NAME}")

    def update_address(self, url, explicit_view=None):
        view = explicit_view or self.sender()
        if view is not self.tabs.currentWidget():
            return
        if view is self.search_view:
            self.address.clear()
            self.address.setPlaceholderText("Custom MultiSearch page")
        else:
            self.address.setPlaceholderText("Enter a website address or search phrase")
            self.address.setText(url.toString())
            self.address.setCursorPosition(0)

    def update_title(self, title):
        view = self.sender()
        index = self.tabs.indexOf(view)
        if index < 0:
            return
        title = title.strip() or str(view.property("base_title") or "Browser")
        short = title if len(title) <= 30 else title[:29] + "…"
        self.tabs.setTabText(index, short)
        self.tabs.setTabToolTip(index, title)
        if view is self.tabs.currentWidget():
            self.setWindowTitle(f"{title} - {APP_NAME}")

    def update_icon(self, icon):
        view = self.sender()
        index = self.tabs.indexOf(view)
        if index >= 0:
            self.tabs.setTabIcon(index, icon)

    def load_started(self, view):
        if view is self.tabs.currentWidget():
            self.show_status("Loading...")

    def load_progress(self, view, progress):
        if view is self.tabs.currentWidget():
            self.show_status(f"Loading: {progress}%")

    def load_finished(self, view, ok):
        if view is self.tabs.currentWidget():
            self.show_status("Finished loading" if ok else "Page could not be loaded")

    def focus_address(self):
        if self.tabs.currentWidget() is self.search_view:
            self.create_blank_tab()
        self.address.setFocus()
        self.address.selectAll()

    def next_tab(self):
        if self.tabs.count() > 1:
            self.tabs.setCurrentIndex((self.tabs.currentIndex() + 1) % self.tabs.count())

    def previous_tab(self):
        if self.tabs.count() > 1:
            self.tabs.setCurrentIndex((self.tabs.currentIndex() - 1) % self.tabs.count())

    def show_status(self, message):
        self.status_label.setText(str(message))


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("WritersJumbler")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
