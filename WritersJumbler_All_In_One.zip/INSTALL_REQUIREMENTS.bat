@echo off
setlocal
cd /d "%~dp0"
title WritersJumbler Setup

echo ========================================
echo  WritersJumbler Python Package Installer
echo ========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    set "PY=python"
  ) else (
    echo Python was not found.
    echo Install Python 3, then run this installer again.
    echo https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
  )
)

echo Using Python:
%PY% --version
echo.
echo Updating pip...
%PY% -m pip install --upgrade pip
if errorlevel 1 goto :failed

echo.
echo Installing WritersJumbler packages...
%PY% -m pip install --upgrade pillow google-api-python-client google-auth-httplib2 google-auth-oauthlib
if errorlevel 1 goto :failed

echo.
echo ========================================
echo  INSTALL COMPLETE
echo ========================================
echo Run WritersJumbler_All_In_One.py to start.
echo.
pause
exit /b 0

:failed
echo.
echo ========================================
echo  INSTALL FAILED
echo ========================================
echo Check your Internet connection and Python installation.
pause
exit /b 1
