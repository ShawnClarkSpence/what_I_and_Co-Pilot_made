@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py WritersJumbler_All_In_One.py
) else (
  python WritersJumbler_All_In_One.py
)
if errorlevel 1 pause
