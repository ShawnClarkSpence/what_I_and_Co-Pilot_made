import tkinter as tk
from tkinter import ttk, messagebox, filedialog, colorchooser
from pathlib import Path
from email.message import EmailMessage
import os, base64, json, queue, threading, mimetypes, random
try:
    from PIL import Image
except ImportError: Image=None
try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
except ImportError:
    Request=Credentials=InstalledAppFlow=build=None

APP='WritersJumbler Gmail + Word Art + Grid Art'
PRIVATE=Path(os.getenv('LOCALAPPDATA',Path.home()/'.writersjumbler'))/'WritersJumbler'
PRIVATE.mkdir(parents=True,exist_ok=True)
CLIENT=PRIVATE/'google_client_secret.json'; TOKEN=PRIVATE/'token.json'
SCOPES=['https://www.googleapis.com/auth/gmail.readonly','https://www.googleapis.com/auth/gmail.send']
BG,NAVY,WHITE='#c0c0c0','#000080','#ffffff'

def dec(s): return base64.urlsafe_b64decode(s+'='*(-len(s)%4)) if s else b''
def hdr(h,n): return next((x.get('value','') for x in h if x.get('name','').lower()==n.lower()),'')
def body_text(p):
    if p.get('mimeType')=='text/plain' and p.get('body',{}).get('data'): return dec(p['body']['data']).decode('utf-8','replace')
    for q in p.get('parts',[]):
        v=body_text(q)
        if v:return v
    return ''

class App(tk.Tk):
 def __init__(self):
  super().__init__(); self.title(APP); self.geometry('1220x820'); self.minsize(940,650); self.configure(bg=BG)
  self.service=None; self.items=[]; self.files=[]; self.q=queue.Queue(); self.status=tk.StringVar(value='Ready')
  self.n=20; self.pix=[[WHITE]*20 for _ in range(20)]; self.paint=NAVY; self.cs=600; self.drawing=self.erasing=False
  s=ttk.Style(self); s.theme_use('clam'); s.configure('.',font=('Courier New',10)); s.configure('Treeview',rowheight=23)
  tk.Label(self,text=' WRITERSJUMBLER ALL-IN-ONE ',bg=NAVY,fg=WHITE,font=('Courier New',15,'bold'),anchor='w',pady=8).pack(fill='x')
  nav=tk.Frame(self,bg=BG);nav.pack(fill='x');self.host=tk.Frame(self,bg=BG);self.host.pack(fill='both',expand=True,padx=5,pady=5)
  self.pages={}; self.inbox();self.compose();self.wordart();self.gridart();self.signin_page()
  for n in ('INBOX','COMPOSE','WORD ART','GRID ART','GOOGLE SIGN IN'): ttk.Button(nav,text=n,command=lambda x=n:self.show(x)).pack(side='left',padx=2,pady=3)
  tk.Label(self,textvariable=self.status,bg=BG,relief='sunken',anchor='w').pack(fill='x'); self.show('INBOX'); self.after(100,self.poll)
 def page(self,n): p=tk.Frame(self.host,bg=BG);self.pages[n]=p;return p
 def show(self,n):
  for p in self.pages.values():p.pack_forget()
  self.pages[n].pack(fill='both',expand=True)
  if n=='GRID ART':self.after_idle(self.draw)
 def inbox(self):
  p=self.page('INBOX');bar=tk.Frame(p,bg=BG);bar.pack(fill='x');ttk.Button(bar,text='SIGN IN / REFRESH',command=self.refresh).pack(side='left');ttk.Button(bar,text='SAVE ATTACHMENTS',command=self.save_attach).pack(side='left')
  self.count=tk.IntVar(value=25);ttk.Spinbox(bar,from_=1,to=100,textvariable=self.count,width=5).pack(side='left',padx=8)
  self.tree=ttk.Treeview(p,columns=('from','subject','date'),show='headings',height=12)
  for c,w in (('from',280),('subject',520),('date',250)):self.tree.heading(c,text=c.upper());self.tree.column(c,width=w)
  self.tree.pack(fill='both',expand=True);self.tree.bind('<<TreeviewSelect>>',self.read)
  self.reader=tk.Text(p,wrap='word',height=13);self.reader.pack(fill='both',expand=True)
 def compose(self):
  p=self.page('COMPOSE');f=tk.Frame(p,bg=BG);f.pack(fill='x');self.to,self.cc,self.subject=tk.StringVar(),tk.StringVar(),tk.StringVar()
  for r,(a,v) in enumerate((('TO',self.to),('CC',self.cc),('SUBJECT',self.subject))):tk.Label(f,text=a,bg=BG,width=10).grid(row=r,column=0);tk.Entry(f,textvariable=v).grid(row=r,column=1,sticky='ew')
  f.columnconfigure(1,weight=1);self.mailbody=tk.Text(p,wrap='word');self.mailbody.pack(fill='both',expand=True)
  b=tk.Frame(p,bg=BG);b.pack(fill='x');ttk.Button(b,text='ATTACH FILES',command=self.attach).pack(side='left');self.al=tk.StringVar(value='No attachments');tk.Label(b,textvariable=self.al,bg=BG).pack(side='left');ttk.Button(b,text='SEND',command=self.send).pack(side='right')
 def wordart(self):
  p=self.page('WORD ART');b=tk.Frame(p,bg=BG);b.pack(fill='x');self.effect=tk.StringVar(value='Normal');ttk.Combobox(b,textvariable=self.effect,values=['Normal','UPPERCASE','lowercase','S p a c e d','Boxed','Banner','Reverse','Shadow'],state='readonly').pack(side='left')
  for n,c in [('APPLY',self.applyword),('COLOR',self.wordcolor),('LOAD',self.wordload),('SAVE',self.wordsave),('SEND IN EMAIL',self.wordmail)]:ttk.Button(b,text=n,command=c).pack(side='left',padx=2)
  self.word=tk.Text(p,wrap='word',undo=True,font=('Courier New',18));self.word.pack(fill='both',expand=True);self.word.insert('1.0','WritersJumbler Word Art')
 def gridart(self):
  p=self.page('GRID ART');tk.Label(p,text='GRID ART 20x20 TO 100x100 - MIRRORED RANDOM - NO RED LINE',bg=NAVY,fg=WHITE,font=('Courier New',13,'bold')).pack(fill='x')
  a=tk.Frame(p,bg=BG);a.pack(fill='x');ttk.Button(a,text='ZOOM OUT -1',command=lambda:self.resize(self.n-1)).pack(side='left');self.sl=tk.StringVar(value='20 x 20');tk.Label(a,textvariable=self.sl,bg=BG,width=12).pack(side='left');ttk.Button(a,text='ZOOM IN +1',command=lambda:self.resize(self.n+1)).pack(side='left')
  for n,c in [('COLOR',self.pick),('RANDOM SYMMETRY',self.rand),('CLEAR',self.clear),('LOAD GRID',self.gridload),('SAVE GRID',self.gridsave),('EXPORT PNG',self.png),('SEND GRID AS TEXT',self.gridmail)]:ttk.Button(a,text=n,command=c).pack(side='left',padx=2)
  self.canvas=tk.Canvas(p,width=self.cs,height=self.cs,bg=WHITE,highlightbackground=NAVY,highlightthickness=2);self.canvas.pack(pady=6)
  self.canvas.bind('<Button-1>',lambda e:self.press(e,False));self.canvas.bind('<B1-Motion>',lambda e:self.paintat(e,False));self.canvas.bind('<Button-3>',lambda e:self.press(e,True));self.canvas.bind('<B3-Motion>',lambda e:self.paintat(e,True))
 def signin_page(self):
  p=self.page('GOOGLE SIGN IN');tk.Label(p,text='GOOGLE OAUTH2',bg=NAVY,fg=WHITE,font=('Courier New',20,'bold')).pack(fill='x');tk.Label(p,text='Each user must choose their own Desktop OAuth JSON.\nPrivate credentials are stored in the user local application-data folder.',bg=BG,pady=20).pack()
  ttk.Button(p,text='CHOOSE DESKTOP OAUTH JSON',command=self.choose).pack(pady=5);ttk.Button(p,text='GOOGLE OAUTH2 SIGN IN',command=lambda:self.bg(self.gmail,lambda x:messagebox.showinfo('Gmail','Connected'))).pack(pady=5);ttk.Button(p,text='CLEAR SAVED TOKEN',command=self.cleartoken).pack(pady=5)
 def bg(self,fn,done):threading.Thread(target=lambda:self.worker(fn,done),daemon=True).start()
 def worker(self,fn,done):
  try:self.q.put((done,fn(),None))
  except Exception as e:self.q.put((None,None,str(e)))
 def poll(self):
  try:
   while 1:
    d,x,e=self.q.get_nowait()
    if e:messagebox.showerror(APP,e);self.status.set('ERROR: '+e)
    elif d:d(x)
  except queue.Empty:pass
  self.after(100,self.poll)
 def creds(self):
  if not all((Request,Credentials,InstalledAppFlow,build)):raise RuntimeError('Install Google API libraries using INSTALL_REQUIREMENTS.bat')
  c=None
  if TOKEN.exists():
   try:c=Credentials.from_authorized_user_file(str(TOKEN),SCOPES)
   except Exception:pass
  if c and c.expired and c.refresh_token:c.refresh(Request())
  if not c or not c.valid:
   if not CLIENT.exists():raise RuntimeError('Choose your Desktop OAuth JSON first.')
   c=InstalledAppFlow.from_client_secrets_file(str(CLIENT),SCOPES).run_local_server(port=0,open_browser=True);TOKEN.write_text(c.to_json(),encoding='utf-8')
  return c
 def gmail(self):
  if not self.service:self.service=build('gmail','v1',credentials=self.creds(),cache_discovery=False)
  return self.service
 def choose(self):
  f=filedialog.askopenfilename(filetypes=[('OAuth JSON','*.json')]);
  if not f:return
  d=json.loads(Path(f).read_text(encoding='utf-8'))
  if 'installed' not in d:messagebox.showerror('OAuth','Choose a Desktop app OAuth JSON.');return
  CLIENT.write_text(json.dumps(d,indent=2),encoding='utf-8');self.status.set('OAuth JSON stored privately.')
 def cleartoken(self):
  self.service=None
  if TOKEN.exists():TOKEN.unlink()
  self.status.set('Token removed.')
 def refresh(self):
  def go():
   s=self.gmail();out=[]
   for i in s.users().messages().list(userId='me',labelIds=['INBOX'],maxResults=max(1,min(100,self.count.get()))).execute().get('messages',[]):
    m=s.users().messages().get(userId='me',id=i['id'],format='full').execute();p=m.get('payload',{});h=p.get('headers',[]);out.append({'id':i['id'],'from':hdr(h,'From'),'subject':hdr(h,'Subject'),'date':hdr(h,'Date'),'body':body_text(p) or m.get('snippet',''),'payload':p})
   return out
  self.bg(go,self.loaded)
 def loaded(self,x):
  self.items=x;self.tree.delete(*self.tree.get_children())
  for i,m in enumerate(x):self.tree.insert('', 'end',iid=str(i),values=(m['from'],m['subject'],m['date']))
 def selected(self):s=self.tree.selection();return self.items[int(s[0])] if s else None
 def read(self,e=None):
  m=self.selected()
  if m:self.reader.delete('1.0','end');self.reader.insert('1.0',f"FROM: {m['from']}\nSUBJECT: {m['subject']}\nDATE: {m['date']}\n\n{m['body']}")
 def parts(self,p):
  o=[]
  for q in p.get('parts',[]):
   if q.get('filename'):o.append(q)
   o+=self.parts(q)
  return o
 def save_attach(self):
  m=self.selected();folder=filedialog.askdirectory()
  if not m or not folder:return
  def go():
   n=0;s=self.gmail()
   for p in self.parts(m['payload']):
    d=p.get('body',{}).get('data');a=p.get('body',{}).get('attachmentId')
    if a:d=s.users().messages().attachments().get(userId='me',messageId=m['id'],id=a).execute().get('data')
    if d:(Path(folder)/Path(p['filename']).name).write_bytes(dec(d));n+=1
   return n
  self.bg(go,lambda n:self.status.set(f'Saved {n} attachment(s).'))
 def attach(self):self.files=list(filedialog.askopenfilenames());self.al.set(f'{len(self.files)} attachment(s)')
 def send(self):
  if not self.to.get().strip():messagebox.showwarning('Compose','Enter a recipient.');return
  m=EmailMessage();m['To']=self.to.get().strip();m['Subject']=self.subject.get();
  if self.cc.get().strip():m['Cc']=self.cc.get().strip()
  m.set_content(self.mailbody.get('1.0','end-1c'))
  for f in self.files:t,_=mimetypes.guess_type(f);a,b=(t or 'application/octet-stream').split('/',1);m.add_attachment(Path(f).read_bytes(),maintype=a,subtype=b,filename=Path(f).name)
  raw=base64.urlsafe_b64encode(m.as_bytes()).decode();self.bg(lambda:self.gmail().users().messages().send(userId='me',body={'raw':raw}).execute(),lambda r:self.status.set('Sent: '+r.get('id','')))
 def applyword(self):
  try:a,b='sel.first','sel.last';x=self.word.get(a,b)
  except tk.TclError:a,b='1.0','end-1c';x=self.word.get(a,b)
  e=self.effect.get();y={'UPPERCASE':x.upper(),'lowercase':x.lower(),'S p a c e d':' '.join(x),'Banner':'*** '+x.upper()+' ***','Reverse':x[::-1]}.get(e,x)
  if e=='Boxed':q=x.splitlines()or[''];w=max(map(len,q));y='+'+'-'*(w+2)+'+\n'+'\n'.join('| '+z.ljust(w)+' |' for z in q)+'\n+'+'-'*(w+2)+'+'
  if e=='Shadow':y='\n'.join(z+'\n '+z for z in x.splitlines())
  self.word.delete(a,b);self.word.insert(a,y)
 def wordcolor(self):
  c=colorchooser.askcolor()[1]
  if c:self.word.tag_configure(c,foreground=c);self.word.tag_add(c,'sel.first','sel.last')
 def wordload(self):
  f=filedialog.askopenfilename();
  if f:self.word.delete('1.0','end');self.word.insert('1.0',Path(f).read_text(encoding='utf-8'))
 def wordsave(self):
  f=filedialog.asksaveasfilename(defaultextension='.txt');
  if f:Path(f).write_text(self.word.get('1.0','end-1c'),encoding='utf-8')
 def wordmail(self):self.mailbody.delete('1.0','end');self.mailbody.insert('1.0',self.word.get('1.0','end-1c'));self.subject.set('WritersJumbler Word Art');self.show('COMPOSE')
 def bounds(self,x,y):s=self.cs;n=self.n;return x*s//n,y*s//n,(x+1)*s//n,(y+1)*s//n
 def draw(self):
  self.canvas.delete('all')
  for y in range(self.n):
   for x in range(self.n):self.canvas.create_rectangle(*self.bounds(x,y),fill=self.pix[y][x],outline='')
  if self.n<=60:
   for i in range(self.n+1):p=i*self.cs//self.n;self.canvas.create_line(p,0,p,self.cs,fill='#c8c8c8');self.canvas.create_line(0,p,self.cs,p,fill='#c8c8c8')
 def resize(self,n):
  n=max(20,min(100,n))
  if n==self.n:return
  old,on=self.pix,self.n;self.pix=[[old[min(on-1,y*on//n)][min(on-1,x*on//n)] for x in range(n)] for y in range(n)];self.n=n;self.sl.set(f'{n} x {n}');self.draw()
 def pick(self):
  c=colorchooser.askcolor(color=self.paint)[1]
  if c:self.paint=c
 def press(self,e,erase):self.paintat(e,erase)
 def paintat(self,e,erase):x=max(0,min(self.n-1,e.x*self.n//self.cs));y=max(0,min(self.n-1,e.y*self.n//self.cs));self.pix[y][x]=WHITE if erase else self.paint;self.canvas.create_rectangle(*self.bounds(x,y),fill=self.pix[y][x],outline='#c8c8c8' if self.n<=60 else '')
 def rand(self):
  # Random symmetric pattern uses ONE selected paint color plus white background.
  n=self.n;self.pix=[[WHITE]*n for _ in range(n)]
  for y in range(n):
   for x in range((n+1)//2):
    v=self.paint if random.random()<0.5 else WHITE
    self.pix[y][x]=self.pix[y][n-1-x]=v
  self.draw();self.status.set(f'Random symmetry generated using one color: {self.paint}')
 def clear(self):self.pix=[[WHITE]*self.n for _ in range(self.n)];self.draw()
 def gridsave(self):
  f=filedialog.asksaveasfilename(defaultextension='.wjg');
  if f:Path(f).write_text(json.dumps({'size':self.n,'pixels':self.pix}),encoding='utf-8')
 def gridload(self):
  f=filedialog.askopenfilename(filetypes=[('WJ Grid','*.wjg')]);
  if not f:return
  d=json.loads(Path(f).read_text());n=int(d['size']);p=d['pixels']
  if not 20<=n<=100 or len(p)!=n or any(len(r)!=n for r in p):messagebox.showerror('Grid','Invalid grid file.');return
  self.n,self.pix=n,p;self.sl.set(f'{n} x {n}');self.draw()
 def png(self):
  if Image is None:messagebox.showerror('PNG','Install Pillow.');return
  f=filedialog.asksaveasfilename(defaultextension='.png',initialfile=f'WritersJumbler_{self.n}x{self.n}.png')
  if not f:return
  im=Image.new('RGB',(self.n,self.n));px=im.load()
  for y in range(self.n):
   for x in range(self.n):v=self.pix[y][x].lstrip('#');px[x,y]=tuple(int(v[i:i+2],16) for i in (0,2,4))
  im.save(f)
 def gridmail(self):
  # One character per grid cell: # for a colored cell, space for white.
  text=f'WritersJumbler {self.n}x{self.n} Grid Art\n\n'+\
       '\n'.join(''.join(' ' if c.lower()=='#ffffff' else '#' for c in r) for r in self.pix)
  self.files=[];self.al.set('No attachments');self.mailbody.delete('1.0','end');self.mailbody.insert('1.0',text);self.subject.set(f'WritersJumbler {self.n}x{self.n} Grid Art');self.show('COMPOSE')

if __name__=='__main__':App().mainloop()
