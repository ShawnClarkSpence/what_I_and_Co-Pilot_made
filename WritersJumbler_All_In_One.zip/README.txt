
SHARING / FIRST-TIME INSTALL
1. Send the entire ZIP file to the other person.
2. They extract the ZIP to a folder.
3. They run INSTALL_REQUIREMENTS.bat once. Internet access is required for pip to download packages.
4. They run RUN_WRITERSJUMBLER.bat or WritersJumbler_All_In_One.py.
5. To use Gmail, they follow the Gmail setup section above and use their own OAuth credentials.

The package installer installs:
- Pillow
- google-api-python-client
- google-auth-httplib2
- google-auth-oauthlib

Tkinter is provided by standard Windows Python installations and is not installed through pip.

============================================================
DETAILED GMAIL OAUTH2 SETUP + OFFICIAL LINKS
============================================================

Each person you share WritersJumbler with should use their OWN Google account and their OWN OAuth Desktop credential file. Do not give them your token.json or your OAuth JSON.

1. CREATE OR SELECT A GOOGLE CLOUD PROJECT
   Google Cloud Console:
   https://console.cloud.google.com/

2. ENABLE THE GMAIL API
   Direct Gmail API enable page:
   https://console.cloud.google.com/apis/enableflow?apiid=gmail.googleapis.com

3. CONFIGURE GOOGLE AUTH / OAUTH CONSENT
   Google Auth Platform - Branding:
   https://console.developers.google.com/auth/branding

   Set the app name and support/contact information.

4. CONFIGURE THE AUDIENCE
   Google Auth Platform - Audience:
   https://console.developers.google.com/auth/audience

   For an app used outside a Google Workspace organization, configure it for External users. If the app is still in Testing, configure the users who are allowed to test it as required by Google.

5. CONFIGURE DATA ACCESS / SCOPES
   Google Auth Platform - Data Access:
   https://console.developers.google.com/auth/scopes

   WritersJumbler uses these Gmail OAuth scopes:
   https://www.googleapis.com/auth/gmail.readonly
   https://www.googleapis.com/auth/gmail.send

6. CREATE A DESKTOP OAUTH CLIENT
   Google Auth Platform - Clients:
   https://console.developers.google.com/auth/clients

   Click Create Client.
   Choose Application type: Desktop app.
   Give it a name such as WritersJumbler.
   Create the client and download its JSON file.

7. LOAD THE JSON INTO WRITERSJUMBLER
   Run WritersJumbler.
   Open GOOGLE SIGN IN.
   Click CHOOSE DESKTOP OAUTH JSON.
   Select the downloaded Desktop OAuth JSON file.

8. SIGN IN
   Click GOOGLE OAUTH2 SIGN IN.
   A browser window opens for Google authorization.
   Sign in to the Google account that will use WritersJumbler and complete Google's authorization screen.

9. PRIVATE LOCAL FILES
   WritersJumbler stores the selected OAuth JSON and generated token outside the shared program folder.

   On Windows:
   %LOCALAPPDATA%\WritersJumbler\

   Do NOT share:
   google_client_secret.json
   token.json

10. START USING GMAIL
    Return to WritersJumbler and use INBOX / SIGN IN / REFRESH to load mail. COMPOSE is used to create and send messages.

OFFICIAL GOOGLE DOCUMENTATION
Gmail API Python Quickstart:
https://developers.google.com/workspace/gmail/api/quickstart/python

OAuth 2.0 for Desktop Apps:
https://developers.google.com/identity/protocols/oauth2/native-app

Google OAuth Best Practices:
https://developers.google.com/identity/protocols/oauth2/resources/best-practices
